/*
 * ABSTRACT
 */
package GameState;

import java.awt.Graphics2D;

/**
 *
 * @author Family
 */
public abstract class GameState {
    
    protected GameStateManager gsm;
    
    public abstract void init();
    public abstract void update();
    public abstract void draw(Graphics2D g);
   //REMOVE public abstract void keyPressed(int k);
   // public abstract void keyReleased(int k);
    
}
